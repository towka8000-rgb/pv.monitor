# -*- coding: utf-8 -*-
"""
Діагностичний скрипт для HCVR (прошивка 2015р.)
Перевіряє всі можливі CGI-ендпоінти диску і друкує сирі відповіді.

Запуск: python hcvr_disk_probe.py
"""

import requests
from requests.auth import HTTPDigestAuth, HTTPBasicAuth

IP       = "192.168.9.10"
USER     = "admin"
PASSWORD = "Kap1t0wka"

URLS = [
    # --- Ендпоінти що зазвичай працюють на HCVR5108H-S2 ---
    "/cgi-bin/storageDevice.cgi?action=getDeviceAllInfo",
    "/cgi-bin/devStorage.cgi?action=getDeviceInfo",
    "/cgi-bin/devStorage.cgi?action=getDeviceAllInfo",
    "/cgi-bin/devStorage.cgi?action=getInfo",
    # --- Сучасніші Dahua ---
    "/cgi-bin/storageDevice.cgi?action=getHddInfo",
    "/cgi-bin/storageDevice.cgi?action=getHddInfoAll",
    "/cgi-bin/storageDevice.cgi?action=getCapacity",
    # --- configManager варіанти ---
    "/cgi-bin/configManager.cgi?action=getConfig&name=HddManager",
    "/cgi-bin/configManager.cgi?action=getConfig&name=Storage",
    "/cgi-bin/configManager.cgi?action=getConfig&name=StorageInfo",
    "/cgi-bin/configManager.cgi?action=getConfig&name=HddInfo",
    "/cgi-bin/configManager.cgi?action=getConfig&name=LogicInfo",
    "/cgi-bin/configManager.cgi?action=getConfig&name=StorageGlobal",
    # --- magicBox / system info ---
    "/cgi-bin/magicBox.cgi?action=getSystemInfo",
    "/cgi-bin/magicBox.cgi?action=getDeviceType",
    # --- Старий формат HCVR pre-2016 ---
    "/cgi-bin/configManager.cgi?action=getConfig&name=Disk",
    "/cgi-bin/configManager.cgi?action=getConfig&name=DiskManager",
    "/cgi-bin/configManager.cgi?action=getConfig&name=Record",
]

sess = requests.Session()

def req(path):
    url = f"http://{IP}{path}"
    try:
        r = sess.get(url, auth=HTTPDigestAuth(USER, PASSWORD), timeout=6)
        if r.status_code in (401, 403):
            r = sess.get(url, auth=HTTPBasicAuth(USER, PASSWORD), timeout=6)
        return r
    except Exception as e:
        return None

print(f"=== Діагностика диску HCVR {IP} ===\n")

for path in URLS:
    r = req(path)
    if r is None:
        print(f"[TIMEOUT]  {path}")
        continue
    body = r.text.strip()
    if r.status_code == 200 and body and "error" not in body[:30].lower():
        print(f"[OK {r.status_code}]   {path}")
        # Друкуємо перші 400 символів відповіді
        preview = body[:400].replace("\r\n", "\n")
        for line in preview.splitlines():
            print(f"           {line}")
        if len(body) > 400:
            print(f"           ... (ще {len(body)-400} символів)")
        print()
    elif r.status_code == 200 and ("error" in body[:30].lower() or not body):
        print(f"[ERR_BODY] {path}  →  {body[:80]!r}")
    else:
        print(f"[HTTP {r.status_code}]  {path}")

print("\n=== Готово ===")
